<?php 
   session_start();
   if (!isset($_SESSION['user']) || $_SESSION['user'] != 'administator'){
       echo "<h1>Sorry, You are not logged in !!!</h1>";
       exit();
   }
?>
<html>
    <head>
        <title>Welcome !!!</title>
        <meta charset="utf-8">
        <meta name="viewpoint" content="width=device-width, initial-scale=1.0">
    </head>
    <style>
           @import url('https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap');
    *{
      font-family: 'Kanit', sans-serif;
    }
    </style>
    <body>
        <h1>Welcome <?php echo $_SESSION['user'] ?> !!!</h1>
        <h2>the Secret files ??????</h2>
        <br>
        <a href="./scary.zip" download>Dowload Secret file !!!!!!</a>
        <h2>Use john for cracked !!!!</h2>
    </body>
</html>