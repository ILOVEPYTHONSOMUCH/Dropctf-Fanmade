<?php
     session_start();
     if (isset($_POST['log'])){
         $username = $_POST['cuser'];
         $password = $_POST['cpass'];
         if ($username === "pennywise@clownfromhell.com" && $password === "enterprise"){
             $_SESSION['user'] = 'pennywise';
             header("location: user.php");
         }
         else if ($username === "administator@clownfromhell.com" && $password === "clown"){
          $_SESSION['user'] = 'administator';
          header("location: admin.php");
      }
     }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>

    <link rel="stylesheet" href="style.css">
</head>
<style>
  .form-login{
    position: relative;
    top: 30px;
  }
  .center {
  display: block;
  margin-left: auto;
  margin-right: auto;
}
  </style>
<body>
  <br>
  <br>
  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSkl3T-gUSdwW9QxFhjlSwWKD9XzDzDfDemxQ&usqp=CAU" width="400" class="center">
    <div class="form-login">
      <div class="container mt-3">
        <div class="header">
            <h1>Clown System Login</h1>
        </div>
            <form method="post">
              <div class="form-group">
        <!-- Oh you can't input the email ???? Try to fix this below !!!! -->
        <label for="mail">Email address</label>
        <input type="number" name="cuser" class="form-control" id="mail" aria-describedby="emailHelp" placeholder="Enter email">
      </div>
      <div class="form-group">
        <label for="pass">Password</label>
        <input type="password" name="cpass" class="form-control" id="pass" placeholder="Password">
      </div>
      
      <button type="submit" name="log" class="btn btn-primary">Submit</button>
    </form>
    </div>
    </div>
</body>
</html>
 