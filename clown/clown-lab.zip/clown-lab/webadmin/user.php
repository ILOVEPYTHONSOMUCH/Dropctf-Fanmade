<?php 
   session_start();
   if (!isset($_SESSION['user'])){
       echo "<h1>Sorry, You are not logged in !!!</h1>";
       exit();
   }
?>
<html>
    <head>
        <title>Welcome !!!</title>
        <meta charset="utf-8">
        <meta name="viewpoint" content="width=device-width, initial-scale=1.0">
    </head>
    <style>
           @import url('https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap');
    *{
      font-family: 'Kanit', sans-serif;
    }
    </style>
    <body>
        <h1>Welcome <?php echo $_SESSION['user'] ?> !!!</h1>
        <h2>You have 2 mail(s) :</h2>
       <div style="background-color: antiquewhite;padding: 10px;border: 2px solid black;margin: 20px">
       <h3>Dear Pennywise (webste security).<br>Hello pennywise. You do work so good. Now i can login to ssh. Could you decode my password ???. i can't remember my password so i get this hash from database.<br><br>P.S. My hash is "OGI2MWMxMWViOGJhZWRkNTNkMmU5OWQxYTAxZmE3YmI="<br>From administator</h3>
       </div>
        <br>
        <br>
        <div>
        <h3 style="background-color: aquamarine;padding: 10px;border: 2px solid black;margin: 20px">Dear Pennywise (webste security).<br>Hello pennywise. Do you remember our website secret now i just find the hacker who scan our website. fuck !!!! you should to upgrade password hash right now.<br><br>From Robert (Web design)</h3>
        </div>
    </body>
</html>