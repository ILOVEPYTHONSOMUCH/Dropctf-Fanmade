<?php 
  session_start();
  if ((!isset($_SESSION['user'])) || ($_SESSION['user'] != "adminxd")){
    header("location: index.php");
     exit();
  }
  if (isset($_POST['download'])){
    $url = $_POST['url'];
    if (str_ends_with($url, '.png') || str_ends_with($url, '.jpg') || str_ends_with($url, '.gif')) {
        system("cd uploads && wget $url");
    }
    else{
        $error = true;
    }
  }
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>Dashboard !!!</title>
</head>
<body>
    <div class="container m-5">
        <h2>Welcome Back admin to PWNSHOP !!!!</h2>
        <img src="./cathacker.jpg" alt="">
        <br>
        <br>
        <h3>Getting image from internet !!!!!!</h3>
        <br>
        <form method="post">
            <input type="text" name="url" placeholder="URL HERE..." class="form-control w-50">
            <br>
            <button type="submit" class="btn btn-warning" name="download">Downloads</button>
        </form>
        <!-- Remember file extension allow png,jpg,gif only !!!-->
        <br>
        <br>
        <?php
          if (isset($error)){
            echo '<div class="alert alert-danger" role="alert">
            Remember file extension allow png,jpg,gif only !!!
          </div>';
         }
        ?>
    </div>
</body>
</html>