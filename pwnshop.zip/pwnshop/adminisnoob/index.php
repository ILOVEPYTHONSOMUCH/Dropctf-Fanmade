<?php
   session_start();
   if (isset($_POST['log'])){
     $name =  $_POST['user'];
     $pass = $_POST['pass'];
     if ($name == "admin" && $pass == "P@ssw0rd123"){
        $logon = true;
        $_SESSION['user'] = "adminxd";
        header("Location: home.php");
     }
     else{
        $logon = false;
     }
   }
?>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>Login only</title>
</head>
<body>
   <div class="container m-5">
   <div class="d-flex flex-row justify-content-center">
      <div class="">
      <img src="https://www.terracestandard.com/wp-content/uploads/2019/10/19173627_web1_191031-SUM-Halloween-quiz-ONLINE_1.jpg" class="w-25" alt="">
    <h2>BOO !!!  Do you scary ???</h2>
    <form method="post">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Username : </label>
    <input type="text" name="user" class="form-control w-50" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password : </label>
    <input type="password" name="pass" class="form-control w-50" id="exampleInputPassword1">
  </div>
  <button type="submit" name="log" class="btn btn-primary">Submit</button>
  <br>
  <br>
  <?php
     if (isset($logon)){
        echo '<div class="alert alert-danger" role="alert">
       Your Username or Password is incorrect !!!!!
      </div>';
     }
  ?>
</form>
      </div>
   </div>
</div>
</body>
</html>