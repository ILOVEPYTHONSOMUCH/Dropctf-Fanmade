$(document).ready(function (){
    $('.item').click(function () {
        alert("Problem with our database. Please contact administrator !!!");
        // Backup db password is S0me0ne123#! 
    })
})