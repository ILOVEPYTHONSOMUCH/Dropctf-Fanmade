-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 09, 2022 at 05:02 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rickctf`
--

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `id` int(5) NOT NULL,
  `img` varchar(256) NOT NULL,
  `content` varchar(120) NOT NULL,
  `title` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`id`, `img`, `content`, `title`) VALUES
(1, 'https://i.pinimg.com/originals/4b/79/79/4b79793d2fc4b9a87cb307681bb2f186.png', 'Oh , Rick is a pickle. Help Him plzzzzzzz', 'Pickle Rick'),
(2, 'https://media.tenor.com/images/49b47e3fcae596b5295ca6f64b5190e0/tenor.png', 'wubba lubba dub dub is meaning \"I am in great pain.\" ;(', 'wubba lubba dub dub'),
(3, 'https://media.comicbook.com/2021/09/rick-and-morty-portal-gun-broken-cliffhanger-adult-swim-1281947.jpeg?auto=webp&width=1200&height=628&crop=1200:628,smart', 'The Portal Gun is a gadget that allows the user(s) to travel between different universes/dimensions/realities.', 'Portal gun'),
(4, 'https://static1.srcdn.com/wordpress/wp-content/uploads/2020/11/Rick-and-Morty-Birdperson.jpg', 'Birdperson, briefly also known as Phoenixperson, is a friend of Rick Sanchez. He has known Rick for a long time.', 'Bird Person');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data`
--
ALTER TABLE `data`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
