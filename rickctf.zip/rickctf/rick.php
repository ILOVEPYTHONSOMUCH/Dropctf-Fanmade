<?php
  $id = $_POST['id'];
  if (isset($id)){
    $server_db = "localhost";
  $username_db = "root";
  $password_db= "";
  $db = "rickctf"; // database name 
  $conn = mysqli_connect($server_db, $username_db, $password_db, $db);
  $sql = "SELECT * FROM data WHERE id=$id";
  $query_db = mysqli_query($conn, $sql);
  $result = mysqli_fetch_all($query_db);
  $img = $result[0][1];
  $content = $result[0][2];
  $title = $result[0][3];
  }
  else{
    header("location: index.html");
    exit();
  }
?>
<html>
  <head>
    <title><?php echo $title ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
  </head>
   <style>
        @import url('https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap');
        *{
            font-family: 'Kanit', sans-serif;
        }
    </style>
  <body align="center">
      <br>
      <br>
      <h2><?php echo $title ?></h2>
      <br>
      <img src="<?php echo $img; ?>" width="500">
      <br>
      <br>
      <p class="mt-4" style="font-size: 120%;">
      <?php echo $content; ?>
      </p>
  </body>
</html>