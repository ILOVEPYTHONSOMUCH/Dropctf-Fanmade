<?php
     if(isset($_POST['log'])){
      $server_db = "localhost";
      $username_db = "root";
      $password_db= "";
      $db = "rickctf"; // database name 
      $conn = mysqli_connect($server_db, $username_db, $password_db, $db);
      $username = mysqli_real_escape_string($conn, $_POST['user']);
      $password = mysqli_real_escape_string($conn, $_POST['pass']);
      $hash = md5($password);
      $sql1  = "SELECT * FROM user WHERE username='$username' AND password='$hash'";
      $query_db = mysqli_query($conn, $sql1);
      $result = mysqli_fetch_all($query_db);
      if (!$result){
        $error = '<div class="alert alert-danger" role="alert">
        Error : User does not exist / Password incorrect.
      </div>';
      }
      if ($result){
        $user = $result[0][0];
        $jobs = $result[0][2];
        $ciphering = "AES-128-CTR";
        $iv_length = openssl_cipher_iv_length($ciphering);
        $options = 0;
        $encryption_iv = '1234567891011121';
        $encryption_key = "d015cc465bdb4e51987df7fb870472d3fb9a3505";
        $cookie_value = openssl_encrypt($user, $ciphering,
        $encryption_key, $options, $encryption_iv);
        setcookie('auth', $cookie_value, time() + (7200), "/");
        setcookie('jobs', $jobs, time() + (7200), "/");
        header("location: user.php");
      }
     }
?>
<!DOCTYPE html>
<html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Login Panel</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    </head>
    <style>
        form{
            margin-left: 30%;
            margin-right: 30%;
        }
    </style>
    <body>
       <div class="container">
        <br>
        <br>
        <form method="post">
            <img src="https://d.newsweek.com/en/full/680592/10-9-rick-morty-mcdonalds.jpg" width="500"> 
            <h1>Rick Login System</h1>
            <div class="form-outline mb-4">
              <label class="form-label" for="form1Example1">Email address</label>
              <input type="text" id="form1Example1" name="user" class="form-control">
            </div>
            <div class="form-outline mb-4">
              <label class="form-label" for="form1Example2">Password</label>
              <input type="password" id="form1Example2" name="pass" class="form-control">
            </div>
              <br>
            <button type="submit" name="log" class="btn btn-primary btn-block">Sign in</button>
          </form>
          <br>
          <?php if (isset($error)){
           echo $error;
       } ?>
       </div>
  </body>
</html>