<?php
  if (!$_COOKIE['auth']){
    header("location: index.php");
    exit();
}
$cookie = $_COOKIE['auth'];
$ciphering = "AES-128-CTR";
$iv_length = openssl_cipher_iv_length($ciphering);
$options = 0;
$decryption_iv = '1234567891011121';
$decryption_key = "d015cc465bdb4e51987df7fb870472d3fb9a3505";
$decryption=openssl_decrypt($cookie, $ciphering, 
$decryption_key, $options, $decryption_iv);
$user = $decryption;
if ($user == 'picklerick!!!123' && isset($_POST['check'])){
    $url = $_POST['url'];
    $ch = curl_init ($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Cookie: auth=NDG1OS1mYXi2rjWP; jobs=admin"));
    $output = curl_exec ($ch);
    curl_close($ch);

}
if ($user == 'administator' && isset($_POST['write'])){
    $name = $_POST['filename'];
    if(strpos($name,".php") >= 0) {
        $error = '<div class="alert alert-danger" role="alert">
        Error : cannot write php file !!!!!.
      </div>';
    }
    $file = $_POST['txt'];
    $cmd = 'echo '.$file.' > '.$name;
    $output = shell_exec($cmd);
}
?>
<html>
    <head>
        <title>Panel !!!</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    </head>
    <style>
          @import url('https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap');
        *{
            font-family: 'Kanit', sans-serif;
        }
        textarea {
    display: block;
    margin-left: auto;
    margin-right: auto;
}
    </style>
    <br>
    <br>
    <body align="center">
        <h2>Hello, <?php echo $user ?></h2>
        <br>
        <h3>You are <?php echo $_COOKIE['jobs']; ?></h3>
        <br>
        <br>
        <?php if ($user == 'picklerick!!!123'){
            echo "<img src='https://imgix.bustle.com/scary-mommy/2021/01/rick-and-morty.jpg?w=1200&h=630&fit=crop&crop=faces&fm=jpg' width='600'>";}
            if ($user == 'administator'){
                echo "<img src='https://www.slashfilm.com/img/gallery/14-shows-like-rick-morty-that-are-worth-your-time/l-intro-1628182486.jpg' width='600'>";
        } ?>
        <br>
        <br>
        <h3>Your Work :</h3>
        <?php
            if ($user == 'picklerick!!!123'){
                echo '<form method="post"><label for="exampleFormControlTextarea1">Web admin tester (test system by admin cookie). Enter url !!!:</label><br><br>
                <textarea class="form-control" style="font-size: 18px;width: 450px;height: 100px;resize: none;" name="url" id="exampleFormControlTextarea1"  rows="2"></textarea>
                <br><br><button type="submit" name="check" class="btn btn-outline-primary">Send</button>
                <br><br></div></form>';
            }
            if ($user == 'administator'){
                echo '<div align="center"><form method="post"><label for="exampleFormControlTextarea1">File Writer</label><br><br>
                <input type="text" name="filename" class="form-control" style="width: 210px;" placeholder="filename..."><br>
                <textarea class="form-control" style="font-size: 18px;width: 450px;height: 100px;resize: none;" name="txt" id="exampleFormControlTextarea1"  rows="2"></textarea>
                <br><br><button type="submit" name="write" class="btn btn-outline-primary">Save</button>
                <br><br></div></form></div>';
            }
            if (isset($error)){
               echo $error;
            }
        ?>
    </body>
</html>