<?php 
   session_start();
   if (isset($_POST['log'])){
    $user = $_POST['user'];
    $pass = $_POST['pass'];

    if ($user == "mark" && $pass == "4rey0uh4ck3rs1441"){
        $_SESSION['user'] = 'mark@tesla.car';
        header("location: ./home/");
    }
    if ($user == "el0nz4z41337@#" && $pass == "SuP3rSuCuRepASsw0rd<>?!"){
        $_SESSION['user'] = 'elon@tesla.car';
        header("location: ./home/");
    }
   }

?>
<html>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
 <title>Login - Tesla</title>
    </head>
    <body style="background-color: #F4F4F4;">
<style>
    body {
    font-family: "Lato", sans-serif;
}



.main-head{
    height: 150px;
    background: #FFF;
   
}

.sidenav {
    height: 80%;
    background-image: url("https://www.autodeft.com/_uploads/images/Tesla%20Model%20S%20Plaid%20Launch_02.jpg");
    overflow-x: hidden;
    padding-top: 20px;
}


.main {
    padding: 0px 10px;
}

@media screen and (max-height: 450px) {
    .sidenav {padding-top: 15px;}
}

@media screen and (max-width: 450px) {
    .login-form{
        margin-top: 10%;
    }

    .register-form{
        margin-top: 10%;
    }
}

@media screen and (min-width: 768px){
    .main{
        margin-left: 40%; 
    }

    .sidenav{
        width: 40%;
        position: fixed;
        z-index: 1;
        top: 0;
        left: 0;
    }

    .login-form{
        margin-top: 40%;
    }

    .register-form{
        margin-top: 20%;
    }
}


.login-main-text{
    margin-top: 20%;
    padding: 60px;
    color: black;
}

.login-main-text h2{
    font-weight: 300;
}

.btn-black{
    background-color: #000 !important;
    color: #fff;
}
</style>
<div class="sidenav">
         <div class="login-main-text">
            <h2>Telsa Corp.<br> Login Page</h2>
            <br>
            <p>Are you Elon Musk ???</p>
         </div>
      </div>
      <div class="main">
         <div class="col-md-6 col-sm-12">
            <div class="login-form">
               <form method="post">
                  <div class="form-group">
                     <label>User Name</label>
                     <input type="text" name="user" class="form-control" placeholder="User Name">
                  </div>
                  <div class="form-group">
                     <label>Password</label>
                     <input type="password" name="pass" class="form-control" placeholder="Password">
                  </div>
                  <button type="submit" class="btn btn-black" name="log">Login</button>
               </form>
            </div>
         </div>
      </div>
    </body>
</html>