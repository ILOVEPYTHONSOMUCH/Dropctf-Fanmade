<?php
    $user = 'el0nz4z41337@#';
    $pass= 'SuP3rSuCuRepASsw0rd<>?!';
    // Wow you  see password of elon musk's website
?>