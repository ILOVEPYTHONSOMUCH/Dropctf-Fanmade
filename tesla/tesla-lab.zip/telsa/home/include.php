<?php 
     $file = $_GET['file'];
     if (strpos($file, 'http') === false && strpos($file, '..') === false) {
        include($file);
    }
?>