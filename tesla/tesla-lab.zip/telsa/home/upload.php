<?php 
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user'] != "elon@tesla.car"){
    header("location: ../index.html");
    exit();
}
$target_path = "uploads/";  
$target_path = $target_path.basename( $_FILES['fileToUpload']['name']);  
$filetype = $_FILES['fileToUpload']['type'];
$check = strpos(strval($filetype), 'image/');
if ($check !== false){
    if(move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $target_path)) {  
        echo "File uploaded successfully! saved at /uploads/";  
    } else{  
        echo "Sorry, file not uploaded, please try again!";  
    }  
}
else{  
    echo "Wrong file type !!!";  
}  

?>